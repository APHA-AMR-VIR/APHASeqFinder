# June 2015, Central Sequencing Unit, APHA
# Author: Javier Nunez
#
#
# This bash script will run the AMR gene analysis for any number of squencing runs.
#
# go to:
# 	cd /mnt/BactiPipes_MA2017/APHA_pipelines/SeqFinder/software/WGS_GeneMapper
# and run:
#	sh WGS_GeneMapper_mcr1.sh

# Every line calls WGS_GeneMapper_Run providing the following arguments:
# 	arg1 the reference fasta database containing the AMR genes sequences in fasta format
# 	arg2 the name of the run (folder name where the fastq files are stored).
# 	arg3 number of cpus to be used
#
#sleep 24h

softpath="./"
refpath="./references"
#datapath= $1
#resultspath="/mnt/BactiPipes_MA2017/APHA_pipelines/SeqFinder_v1/nick/WGS_results"
cores=30

#sh WGS_GeneMapper_Run.sh JWKG01000081_mcr1.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh colistin_resistance_genes.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh mcr1_gene.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh pHNSHP45_complete_sequence.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh StaphA-Genelist-MS-180815.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh pHNSHP45_sequences.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh pHNSHP45_sequences_without_full_plasmid.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh mcr1_gene_test.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh ISApII_mcr1.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh nikB_ISApII_mcr1.fna  mcr1 $cores $softpath $refpath $datapath $resultspath 
#sh WGS_GeneMapper_Run.sh a-concat-E4.contigs.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh colistin_resistance_genes_101215.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh AMR_genes_20150612_ISApII.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh VirulenceFactors_MAbuOun_Aug2015List.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh Staph_Genes_MS_220216.fna  mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh eurosurveillance_plasmids.fasta mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh Updated_TEM_Alleles.fas mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh mcr2_gene.fna mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh rmt_genes.fasta mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh BacMet_metals_nucleotide.fna mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh AMRDatabase_Colistin_mcr_variants_20170815.fna mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh VirulenceFactors_MAbuOun_Aug2015List.fna mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh AMRDatabase_20170815.fna mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh stx_reference_genes.fa mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh H_and_O_types.fasta mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh O55_primers_wzy_wzx.fasta mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh staph_czr.fna mcr1 $cores $softpath $refpath $datapath $resultspath
#sh WGS_GeneMapper_Run.sh AMRDatabase_20180308_nick.fna mcr1 $cores $softpath $refpath $datapath $resultspath
sh WGS_GeneMapper_Run.sh AMRDatabase_20190501_ND.fna mcr1 $cores $softpath $refpath $1 $1
#sh WGS_GeneMapper_Run.sh Heavy_metals_180713.fas mcr1 $cores $softpath $refpath $datapath $resultspath

